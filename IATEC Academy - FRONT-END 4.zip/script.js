document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const correctUsername = 'Leonan';
    const correctPassword = '123123123';

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === correctUsername && password === correctPassword) {
        alert('Login bem-sucedido!');
    } else {
        alert('Login falhou. Verifique seu nome de usuário e senha.');
    }
});

document.getElementById('registerForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const correctUsername = 'Leonan';
    const correctPassword = '123123123';

    const newUsername = document.getElementById('newUsername').value;
    const newPassword = document.getElementById('newPassword').value;

    if (localStorage.getItem(correctUsername) !== null) {
        alert('Este usuário já está registrado. Escolha outro nome de usuário.');
    } else {
        localStorage.setItem(correctUsername, correctPassword);
        alert('Registro bem-sucedido! Você pode fazer login agora.');
    }
});
