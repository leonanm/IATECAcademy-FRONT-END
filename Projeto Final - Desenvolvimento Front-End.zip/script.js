function addTask() {
    var taskInput = document.getElementById('taskInput');
    var taskTime = document.getElementById('taskTime');
    var taskList = document.getElementById('taskList');

    if (taskInput.value !== '') {
        var newTask = document.createElement('li');
        newTask.className = 'list-group-item d-flex justify-content-between align-items-center';
        newTask.innerHTML = `<span>${taskInput.value}</span><div><span class="mr-2">${taskTime.value}</span><button class="btn btn-danger btn-sm" onclick="deleteTask(this)"><i class="fas fa-trash-alt"></i></button></div>`;
        taskList.appendChild(newTask);
        taskInput.value = '';
        taskTime.value = '';
        checkTaskStatus(newTask);
    }
}

function checkTaskStatus(task) {
    var currentTime = new Date();
    var taskTime = task.querySelector('span.mr-2').textContent;
    var hours = parseInt(taskTime.split(':')[0]);
    var minutes = parseInt(taskTime.split(':')[1]);

    var taskDueTime = new Date(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate(), hours, minutes, 0, 0);

    if (currentTime > taskDueTime) {
        task.classList.add('task-overdue');
    }
}

function deleteTask(button) {
    var task = button.closest('.list-group-item');
    task.parentNode.removeChild(task);
}


setInterval(updateCurrentTime, 1000);

function updateCurrentTime() {
    var currentTimeElement = document.getElementById('currentTime');
    var currentTime = new Date();
    var hours = currentTime.getHours();
    var minutes = currentTime.getMinutes();
    var seconds = currentTime.getSeconds();

    currentTimeElement.textContent = formatTime(hours) + ':' + formatTime(minutes) + ':' + formatTime(seconds);

    var tasks = document.querySelectorAll('.list-group-item');
    tasks.forEach(function (task) {
        checkTaskStatus(task);
    });
}

function formatTime(time) {
    return time < 10 ? '0' + time : time;
}
